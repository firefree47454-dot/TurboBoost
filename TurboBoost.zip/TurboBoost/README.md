# ⚡ Turbo Boost

A no-nonsense Android Game Booster built with Kotlin + Jetpack Compose.

**Target:** low-end Android (minSdk 26, Snapdragon 450, 4 GB RAM)

## Features (Step 1)
- Animated BOOST button that kills background processes
- Live RAM, CPU, storage and battery temperature monitoring
- Game Mode toggle
- Dark cyber/neon theme
- Honest metrics — real numbers, no fake claims

## Build

### GitHub Actions (recommended)
1. Push this repo to GitHub
2. Go to **Actions** → **Build Debug APK** → **Run workflow**
3. Download the APK from the workflow artifacts

### Local (Android Studio)
1. Open the project in Android Studio Hedgehog (2023.1.1) or later
2. Sync Gradle
3. Run → app

## Project Status
- [x] Step 1 — Home screen, build system, CI
- [ ] Step 2 — RAM cleaner + Shizuku
- [ ] Step 3 — Storage cleaner with preview
- [ ] Step 4 — Floating bubble overlay
- [ ] Step 5 — Game library + auto boost
- [ ] Step 6 — Performance helpers, DND, settings

## License
Private project — all rights reserved.
