package com.turboboost.app.util

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.io.File

/**
 * Reads real device stats. No fake numbers.
 * Every call is wrapped in try/catch so the app never crashes from a system read.
 */
object SystemMonitor {

    // ── Data classes ──

    data class RamInfo(
        val totalMB: Long,
        val availableMB: Long,
        val usedMB: Long
    )

    data class CpuSnapshot(
        val user: Long,
        val nice: Long,
        val system: Long,
        val idle: Long,
        val ioWait: Long
    ) {
        val total: Long get() = user + nice + system + idle + ioWait
    }

    data class StorageInfo(
        val totalGB: Float,
        val availableGB: Float,
        val usedGB: Float
    )

    // ── RAM ──

    fun getRamInfo(context: Context): RamInfo {
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            val totalMB = memInfo.totalMem / (1024L * 1024L)
            val availMB = memInfo.availMem / (1024L * 1024L)
            RamInfo(totalMB, availMB, totalMB - availMB)
        } catch (e: Exception) {
            RamInfo(0, 0, 0)
        }
    }

    // ── CPU ──

    fun getCpuSnapshot(): CpuSnapshot? {
        return try {
            val line = File("/proc/stat").readLines()
                .firstOrNull { it.startsWith("cpu ") } ?: return null
            val parts = line.trim().split("\\s+".toRegex())
            if (parts.size < 5) return null
            CpuSnapshot(
                user = parts[1].toLongOrNull() ?: 0,
                nice = parts[2].toLongOrNull() ?: 0,
                system = parts[3].toLongOrNull() ?: 0,
                idle = parts[4].toLongOrNull() ?: 0,
                ioWait = if (parts.size > 5) parts[5].toLongOrNull() ?: 0 else 0
            )
        } catch (e: Exception) {
            null
        }
    }

    fun getCpuLoadPercent(prev: CpuSnapshot, curr: CpuSnapshot): Float {
        val prevIdle = prev.idle + prev.ioWait
        val currIdle = curr.idle + curr.ioWait
        val totalDiff = curr.total - prev.total
        val idleDiff = currIdle - prevIdle
        return if (totalDiff > 0) {
            ((totalDiff - idleDiff).toFloat() / totalDiff * 100f).coerceIn(0f, 100f)
        } else {
            0f
        }
    }

    // ── Storage ──

    fun getStorageInfo(): StorageInfo {
        return try {
            val stat = StatFs(Environment.getDataDirectory().path)
            val totalBytes = stat.totalBytes
            val availBytes = stat.availableBytes
            val totalGB = totalBytes / (1024f * 1024f * 1024f)
            val availGB = availBytes / (1024f * 1024f * 1024f)
            StorageInfo(totalGB, availGB, totalGB - availGB)
        } catch (e: Exception) {
            StorageInfo(0f, 0f, 0f)
        }
    }

    // ── Battery temperature ──

    fun getBatteryTemperature(context: Context): Float {
        return try {
            val intent = context.registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
            val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            temp / 10f   // API returns tenths of a degree
        } catch (e: Exception) {
            0f
        }
    }
}
