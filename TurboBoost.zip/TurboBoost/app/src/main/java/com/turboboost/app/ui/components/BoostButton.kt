package com.turboboost.app.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.turboboost.app.ui.theme.DarkBackground
import com.turboboost.app.ui.theme.DarkCard
import com.turboboost.app.ui.theme.NeonCyan
import com.turboboost.app.ui.theme.NeonPurple

@Composable
fun BoostButton(
    isBoosting: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "boost_anim")

    // Rotating ring — spins faster while boosting
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (isBoosting) 800 else 4000,
                easing = LinearEasing
            )
        ),
        label = "ring_rotation"
    )

    // Pulsing glow
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    // Press-down scale
    val scale by animateFloatAsState(
        targetValue = if (isBoosting) 0.93f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "button_scale"
    )

    val buttonSize = 180.dp
    val totalSize = buttonSize + 40.dp

    Box(
        modifier = modifier
            .size(totalSize)
            .scale(scale),
        contentAlignment = Alignment.Center
    ) {
        // ── Rotating outer ring (3 arc segments) ──
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeW = 4.dp.toPx()
            val arcSize = Size(
                size.width - strokeW * 2,
                size.height - strokeW * 2
            )
            val arcOffset = Offset(strokeW, strokeW)

            val segmentCount = 3
            val segmentAngle = 70f
            val gapAngle = (360f - segmentAngle * segmentCount) / segmentCount

            for (i in 0 until segmentCount) {
                val start = ringRotation + i * (segmentAngle + gapAngle)
                drawArc(
                    color = NeonCyan.copy(alpha = glowAlpha),
                    startAngle = start,
                    sweepAngle = segmentAngle,
                    useCenter = false,
                    style = Stroke(width = strokeW, cap = StrokeCap.Round),
                    topLeft = arcOffset,
                    size = arcSize
                )
            }

            // Faint inner ring
            drawCircle(
                color = NeonCyan.copy(alpha = 0.08f),
                radius = size.minDimension / 2 - 20.dp.toPx(),
                style = Stroke(width = 1.dp.toPx())
            )
        }

        // ── Center circular button ──
        Box(
            modifier = Modifier
                .size(buttonSize)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            NeonCyan.copy(alpha = if (isBoosting) 0.15f else 0.05f),
                            DarkCard,
                            DarkBackground
                        )
                    )
                )
                .border(
                    width = 2.dp,
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            NeonCyan.copy(alpha = 0.6f),
                            NeonPurple.copy(alpha = 0.3f),
                            NeonCyan.copy(alpha = 0.15f),
                            NeonPurple.copy(alpha = 0.3f),
                            NeonCyan.copy(alpha = 0.6f)
                        )
                    ),
                    shape = CircleShape
                )
                .clickable(enabled = !isBoosting) { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (isBoosting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(44.dp),
                        color = NeonCyan,
                        strokeWidth = 3.dp
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "BOOSTING",
                        color = NeonCyan,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.FlashOn,
                        contentDescription = "Boost",
                        tint = NeonCyan,
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "BOOST",
                        color = NeonCyan,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 4.sp
                    )
                }
            }
        }
    }
}
