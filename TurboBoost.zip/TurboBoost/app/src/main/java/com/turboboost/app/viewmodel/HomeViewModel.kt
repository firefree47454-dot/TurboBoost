package com.turboboost.app.viewmodel

import android.app.ActivityManager
import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.turboboost.app.util.SystemMonitor
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    // ── State flows ──

    private val _ramInfo = MutableStateFlow(SystemMonitor.RamInfo(0, 0, 0))
    val ramInfo: StateFlow<SystemMonitor.RamInfo> = _ramInfo.asStateFlow()

    private val _cpuLoad = MutableStateFlow(0f)
    val cpuLoad: StateFlow<Float> = _cpuLoad.asStateFlow()

    private val _storageInfo = MutableStateFlow(SystemMonitor.StorageInfo(0f, 0f, 0f))
    val storageInfo: StateFlow<SystemMonitor.StorageInfo> = _storageInfo.asStateFlow()

    private val _batteryTemp = MutableStateFlow(0f)
    val batteryTemp: StateFlow<Float> = _batteryTemp.asStateFlow()

    private val _gameModeEnabled = MutableStateFlow(false)
    val gameModeEnabled: StateFlow<Boolean> = _gameModeEnabled.asStateFlow()

    private val _isBoosting = MutableStateFlow(false)
    val isBoosting: StateFlow<Boolean> = _isBoosting.asStateFlow()

    private val _boostResult = MutableStateFlow<String?>(null)
    val boostResult: StateFlow<String?> = _boostResult.asStateFlow()

    private var prevCpuSnapshot: SystemMonitor.CpuSnapshot? = null
    private var monitorJob: Job? = null

    init {
        startMonitoring()
    }

    // ── Live monitoring (every 2 seconds) ──

    private fun startMonitoring() {
        monitorJob = viewModelScope.launch {
            // Take initial CPU snapshot
            prevCpuSnapshot = SystemMonitor.getCpuSnapshot()
            delay(500)

            while (isActive) {
                try {
                    val ctx = getApplication<Application>()

                    _ramInfo.value = SystemMonitor.getRamInfo(ctx)
                    _storageInfo.value = SystemMonitor.getStorageInfo()
                    _batteryTemp.value = SystemMonitor.getBatteryTemperature(ctx)

                    val currentSnapshot = SystemMonitor.getCpuSnapshot()
                    if (currentSnapshot != null && prevCpuSnapshot != null) {
                        _cpuLoad.value = SystemMonitor.getCpuLoadPercent(
                            prevCpuSnapshot!!, currentSnapshot
                        )
                    }
                    prevCpuSnapshot = currentSnapshot
                } catch (e: Exception) {
                    // Never crash from monitoring
                }
                delay(2000)
            }
        }
    }

    // ── Boost action ──

    fun onBoostClick() {
        if (_isBoosting.value) return

        viewModelScope.launch {
            _isBoosting.value = true
            _boostResult.value = null

            val ramBefore = SystemMonitor.getRamInfo(getApplication()).availableMB

            // Kill background processes (basic, no root needed)
            try {
                val am = getApplication<Application>()
                    .getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

                // Get running app processes and kill their background tasks
                val processes = am.runningAppProcesses ?: emptyList()
                val myPackage = getApplication<Application>().packageName

                for (proc in processes) {
                    for (pkg in proc.pkgList) {
                        // Never kill ourselves
                        if (pkg == myPackage) continue
                        try {
                            am.killBackgroundProcesses(pkg)
                        } catch (_: Exception) { }
                    }
                }
            } catch (_: Exception) { }

            // Wait for the system to reclaim memory
            delay(1500)

            // Measure result honestly
            val ramAfter = SystemMonitor.getRamInfo(getApplication()).availableMB
            val freedMB = ramAfter - ramBefore

            _boostResult.value = if (freedMB > 0) {
                "Freed $freedMB MB of RAM"
            } else {
                "System is already optimized"
            }

            _isBoosting.value = false

            // Auto-dismiss the result after 5 seconds
            delay(5000)
            _boostResult.value = null
        }
    }

    // ── Game Mode toggle ──

    fun toggleGameMode() {
        _gameModeEnabled.value = !_gameModeEnabled.value
        // Future: enable DND, block notifications, etc.
    }

    override fun onCleared() {
        super.onCleared()
        monitorJob?.cancel()
    }
}
