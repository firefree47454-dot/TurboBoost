package com.turboboost.app.ui.theme

import androidx.compose.ui.graphics.Color

// ── Primary neon accent colors ──
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDark = Color(0xFF00B8D4)
val NeonPurple = Color(0xFF7C4DFF)
val NeonGreen = Color(0xFF00E676)
val NeonRed = Color(0xFFFF1744)
val NeonOrange = Color(0xFFFF9100)
val NeonYellow = Color(0xFFFFEA00)

// ── Background & surface colors ──
val DarkBackground = Color(0xFF0A0E1A)
val DarkSurface = Color(0xFF141829)
val DarkSurfaceVariant = Color(0xFF1E2338)
val DarkCard = Color(0xFF1A1F33)

// ── Text colors ──
val TextPrimary = Color(0xFFE8EAED)
val TextSecondary = Color(0xFF9AA0A6)
val TextDim = Color(0xFF5F6368)
