package com.turboboost.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.turboboost.app.ui.components.BoostButton
import com.turboboost.app.ui.theme.DarkCard
import com.turboboost.app.ui.theme.DarkSurfaceVariant
import com.turboboost.app.ui.theme.NeonCyan
import com.turboboost.app.ui.theme.NeonGreen
import com.turboboost.app.ui.theme.NeonOrange
import com.turboboost.app.ui.theme.NeonPurple
import com.turboboost.app.ui.theme.NeonRed
import com.turboboost.app.ui.theme.TextPrimary
import com.turboboost.app.ui.theme.TextSecondary
import com.turboboost.app.viewmodel.HomeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: HomeViewModel = viewModel()) {

    val ramInfo by viewModel.ramInfo.collectAsStateWithLifecycle()
    val cpuLoad by viewModel.cpuLoad.collectAsStateWithLifecycle()
    val storageInfo by viewModel.storageInfo.collectAsStateWithLifecycle()
    val batteryTemp by viewModel.batteryTemp.collectAsStateWithLifecycle()
    val gameModeEnabled by viewModel.gameModeEnabled.collectAsStateWithLifecycle()
    val isBoosting by viewModel.isBoosting.collectAsStateWithLifecycle()
    val boostResult by viewModel.boostResult.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("\u26A1", fontSize = 24.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "TURBO BOOST",
                            style = MaterialTheme.typography.titleLarge,
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))

            // ── Boost Button ──
            BoostButton(
                isBoosting = isBoosting,
                onClick = { viewModel.onBoostClick() }
            )

            // ── Boost result banner ──
            AnimatedVisibility(
                visible = boostResult != null,
                enter = slideInVertically { -it } + fadeIn(),
                exit = slideOutVertically { -it } + fadeOut()
            ) {
                boostResult?.let { result ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = NeonGreen.copy(alpha = 0.1f)
                        ),
                        border = BorderStroke(1.dp, NeonGreen.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = result,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            color = NeonGreen,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }

            // ── Temperature warning (> 40°C) ──
            AnimatedVisibility(
                visible = batteryTemp > 40f,
                enter = slideInVertically { -it } + fadeIn(),
                exit = fadeOut()
            ) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = NeonRed.copy(alpha = 0.1f)
                    ),
                    border = BorderStroke(1.dp, NeonRed.copy(alpha = 0.3f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = "Temperature warning",
                            tint = NeonRed,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Text(
                            text = "Device is hot (${"%.1f".format(batteryTemp)}\u00B0C). Take a break!",
                            color = NeonRed,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            // ── Stats Grid (2 × 2) ──
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "RAM",
                    value = "${ramInfo.usedMB} / ${ramInfo.totalMB} MB",
                    progress = if (ramInfo.totalMB > 0)
                        ramInfo.usedMB.toFloat() / ramInfo.totalMB else 0f,
                    progressColor = if (ramInfo.totalMB > 0 &&
                        ramInfo.usedMB.toFloat() / ramInfo.totalMB > 0.85f
                    ) NeonRed else NeonCyan,
                    icon = Icons.Filled.Memory,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "CPU",
                    value = "${cpuLoad.toInt()}%",
                    progress = cpuLoad / 100f,
                    progressColor = when {
                        cpuLoad > 80f -> NeonRed
                        cpuLoad > 50f -> NeonOrange
                        else -> NeonPurple
                    },
                    icon = Icons.Filled.Speed,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Storage",
                    value = "${"%.1f".format(storageInfo.usedGB)} / ${"%.1f".format(storageInfo.totalGB)} GB",
                    progress = if (storageInfo.totalGB > 0f)
                        storageInfo.usedGB / storageInfo.totalGB else 0f,
                    progressColor = NeonGreen,
                    icon = Icons.Filled.Storage,
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Temp",
                    value = "${"%.1f".format(batteryTemp)}\u00B0C",
                    progress = (batteryTemp / 50f).coerceIn(0f, 1f),
                    progressColor = when {
                        batteryTemp > 40f -> NeonRed
                        batteryTemp > 35f -> NeonOrange
                        else -> NeonGreen
                    },
                    icon = Icons.Filled.Thermostat,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(24.dp))

            // ── Game Mode Toggle ──
            GameModeCard(
                enabled = gameModeEnabled,
                onToggle = { viewModel.toggleGameMode() }
            )

            Spacer(Modifier.height(40.dp))
        }
    }
}

// ─────────────────────────────────────────────────
// Stat Card
// ─────────────────────────────────────────────────

@Composable
fun StatCard(
    title: String,
    value: String,
    progress: Float,
    progressColor: Color,
    icon: ImageVector,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = DarkCard),
        border = BorderStroke(1.dp, progressColor.copy(alpha = 0.15f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = progressColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary
                )
            }
            Spacer(Modifier.height(10.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { progress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = progressColor,
                trackColor = progressColor.copy(alpha = 0.1f),
            )
        }
    }
}

// ─────────────────────────────────────────────────
// Game Mode Card
// ─────────────────────────────────────────────────

@Composable
fun GameModeCard(
    enabled: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) NeonCyan.copy(alpha = 0.08f) else DarkCard
        ),
        border = BorderStroke(
            1.dp,
            if (enabled) NeonCyan.copy(alpha = 0.3f) else Color.Transparent
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Filled.SportsEsports,
                    contentDescription = "Game Mode",
                    tint = if (enabled) NeonCyan else TextSecondary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Game Mode",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (enabled)
                            "Active \u2014 optimizations enabled"
                        else
                            "Tap to enable gaming optimizations",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
            Switch(
                checked = enabled,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = NeonCyan,
                    checkedTrackColor = NeonCyan.copy(alpha = 0.3f),
                    uncheckedThumbColor = TextSecondary,
                    uncheckedTrackColor = DarkSurfaceVariant
                )
            )
        }
    }
}
