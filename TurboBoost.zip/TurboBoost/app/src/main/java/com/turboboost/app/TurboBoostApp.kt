package com.turboboost.app

import android.app.Application

class TurboBoostApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // Future steps: Shizuku init, SharedPreferences, etc.
    }
}
